<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>zajeBlog</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body>
    <form action="index.php" method="post">
        <div id="login_panel">
            <h3>Zaloguj się do naszego zajeBlogu!</h3>
            <label for="nick"> Wpisz swój nick:
                <input type="text" name="nick">
            </label>
            <br>
            <label for="haslo"> Wpisz swoje haslo:
                <input type="password" name="haslo" min="8" required>
            </label>
            <br>
            <input type="submit" value="Zaloguj">

        </div>
    </form>

    <?php
    $conn = new mysqli("localhost", "root", "", "blog");

    
    ?>
</body>
</html>